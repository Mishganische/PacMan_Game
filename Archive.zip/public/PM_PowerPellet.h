//
// Created by MIKHAIL ARZUMANOV on 2025. 05. 12..
//

#ifndef PM_POWERPELLET_H
#define PM_POWERPELLET_H

class PowerPellet {
    public:
    int x,y;
    PowerPellet(int x,int y):x(x), y(y) {}
};

#endif //PM_POWERPELLET_H
